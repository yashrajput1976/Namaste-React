import React from "react";
import ReactDOM from "react-dom/client";
import logo from "./src/Swiggy_Logo_2024.png";
/* Components of Our Food-Order App
 * Header
 * - Logo
 * - Nav Items
 * Body
 * - Search Bar
 * - Restaurant-Container
 *  - Restaurant-Card
 *    - Img
 *    - Name of Res, Star Rating, cuisine, delivery time.
 * Footer
 * - Copyright
 * - Links
 * - Address
 * - Contact
 */

const Header = () => (
  <div className="header">
    <div className="logo-container">
      <img className="logo" src={logo} alt="cart" />
    </div>

    <div className="nav-items">
      <ul>
        <li>Home</li>
        <li>About Us</li>
        <li>Contact Us</li>
        <li>
          <img
            className="cart"
            src="https://png.pngtree.com/png-vector/20230412/ourmid/pngtree-food-cart-line-icon-vector-png-image_6701297.png"
            alt="cart"
          />
        </li>
      </ul>
    </div>
  </div>
);

const AppLayout = () => (
  <div className="app">
    <Header />
    {/* Body */}
    {/* Footer */}
  </div>
);

const root = ReactDOM.createRoot(document.getElementById("root"));

root.render(<AppLayout />);
